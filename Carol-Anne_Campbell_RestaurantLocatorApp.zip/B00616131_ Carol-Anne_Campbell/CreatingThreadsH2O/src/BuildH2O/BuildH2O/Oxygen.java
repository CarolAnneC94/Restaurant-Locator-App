package BuildH2O.BuildH2O;

import java.util.concurrent.BrokenBarrierException;

public class Oxygen implements Runnable {
    //Shared variable of class BuildingH2O
       private BuildingH2O barrier;
    
    //Count indicating the total number of hydrogen atoms   
    private static int count = 1;

//@param buildingH2O shared variable     
    public Oxygen(BuildingH2O buildingH2O) {
        this.barrier = buildingH2O;
    }
 
    public void run() {
        try {
            //Waits upon the barrier
            barrier.hydroxyBarrier.await();

            System.out.println("Oxygen atom " + (count++) + " is waiting at barrier.");

            //Checks if enough number of atoms are available
            if (barrier.hydrogen > 1) {
                // If available, bond
                barrier.hydrogenQueue.release(2);
                barrier.hydrogen -= 2;
                barrier.bond();
            } else {
                barrier.oxygen++;
                barrier.oxygenQueue.acquire();
            }
        } catch (InterruptedException | BrokenBarrierException ignored) {
        }
    }
}
