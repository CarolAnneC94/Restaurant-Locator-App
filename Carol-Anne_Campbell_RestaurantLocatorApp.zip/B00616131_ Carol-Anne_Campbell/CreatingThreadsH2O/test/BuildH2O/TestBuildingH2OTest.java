package BuildH2O;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestBuildingH2OTest
{ 
    public TestBuildingH2OTest() 
    {
    }
    
    @BeforeClass
    public static void setUpClass()
    {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() throws Exception {
        System.out.println("Running: tearDown");
    }
    /**
  * Test of main method, of class TestBuildingH2O.
     */
    @Test
    public void testMain() throws Exception {
        System.out.println("main");
        String[] args = null;
        TestBuildingH2O.main(args);
       fail("The test case is a prototype.");
    }
}
